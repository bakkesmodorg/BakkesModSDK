#pragma once
#include "../actorwrapper.h"
#include "../wrapperstructs.h"
#include "spectatorhudwrapper.h"
class BAKKESMOD_PLUGIN_IMPORT ReplayHUDWrapper : public SpectatorHUDWrapper
{
public:
	CONSTRUCTORS(ReplayHUDWrapper)
		 
	
private:
	PIMPL
};
