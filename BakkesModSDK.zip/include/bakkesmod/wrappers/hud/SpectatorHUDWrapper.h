#pragma once
#include "../actorwrapper.h"
#include "../wrapperstructs.h"

class BAKKESMOD_PLUGIN_IMPORT SpectatorHUDWrapper : public ObjectWrapper
{
public:
	CONSTRUCTORS(SpectatorHUDWrapper)


private:
	PIMPL
};
