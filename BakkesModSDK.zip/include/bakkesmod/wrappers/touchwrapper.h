#pragma once
#include "wrapperstructs.h"
#include "objectwrapper.h"

class BAKKESMOD_PLUGIN_IMPORT TouchWrapper : public ObjectWrapper
{
public:
	CONSTRUCTORS(TouchWrapper)

	////AUTO GENERATED
	//GETSETH(int, GravityScale)
	//GETSETH(float, ExplosionTime)
	//GETSETH(char, HitTeamNum)


private:
	PIMPL
};