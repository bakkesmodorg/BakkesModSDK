# BakkesModSDK
Current header files for BakkesMod SDK
